﻿const discord = require("discord-v12"),
	Enmap = require("enmap"),
	client = new discord.Client();

client.commands = new Enmap();

const fs = require("fs"), config = require("./config.json"),
	colors = require("colors");

  process.title = `DARKNESS | Loading...`;
  console.log(` LOADING |`.magenta + ` Wait for the selfbot to load all your commands for better use`.white)

client.on('ready', () => {
	process.title = `Darkness Nuker [${client.user.tag}] - https://youtube.com/c/vilão7`;
    console.clear()  
    console.log(` LOADED |`.green + ` All selfbot commands loaded successfully`.white)
    console.log(`

  8888888b.                   888                                          
  888  "Y88b                  888                                          
  888    888                  888                                          
  888    888  8888b.  888d888 888  888 88888b.   .d88b.  .d8888b  .d8888b  
  888    888     "88b 888P"   888 .88P 888 "88b d8P  Y8b 88K      88K      
  888    888 .d888888 888     888888K  888  888 88888888 "Y8888b. "Y8888b. 
  888  .d88P 888  888 888     888 "88b 888  888 Y8b.          X88      X88 
  8888888P"  "Y888888 888     888  888 888  888  "Y8888   88888P'  88888P'  


  User:`.brightMagenta + ` ${client.user.tag}`.white + `   |  .help`.brightMagenta + ` - Show commands in chat

                    
`.white)
});

fs.readdir("./source/", (err, files) => {
  if (err) return console.error(err);
  files.forEach(file => {
    if (!file.endsWith(".js")) return;
    let props = require(`./source/${file}`);
    let commandName = file.split(".")[0];
    client.commands.set(commandName, props);
  });
});

client.on('message', async (message) => {

  if (message.content.indexOf(config.prefix) !== 0) return

    const args = message.content.slice(config.prefix.length).trim().split(/ +/g)
    const command = args.shift().toLowerCase()
    const cmd = client.commands.get(command)
    if (message.author.id !== client.user.id) return;

    console.log(` [!] Command Started ${command}`.green)

    if (!cmd) {
        console.log(colors.red(` [-] Unknown command.`.red))
      } else {
      cmd.run(client, message, args)
    }
});


client.login(config.token);
