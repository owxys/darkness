const config = require("../config.json");

exports.run = async (client, message, args) => {
  message.delete()

  if (!message.guild.me.hasPermission("MANAGE_CHANNELS")) return console.log(colors.red(`You do not have permission for such action`))

    for(qtd = 0; qtd < 20; qtd++) {
      await message.guild.createChannel(config.channels, { type: 'text' })
    }
  }
