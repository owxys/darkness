const Discord = require('discord-v12'),
  config = require("../config.json");

module.exports.run = (client, message) => {
    message.delete();
    const embed = new Discord.RichEmbed()
    .addField('nuke', ' ``Fuck the server``', false)
    .addField('create', ' ``Spam 20 channels``', false)
    .addField('everyones', ' ``Mention everyones``', false)
    .addField('ban', ' ``Ban all members``', false)
    .addField('fastban', ' ``Ban high speed``', false)
    .setColor("#2f3136")

    message.channel.send(embed);
}